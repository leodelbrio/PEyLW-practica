

function validar()
{
    // Elimine estas lineas de codigo cuando empiece a trabajar
    alert("Funciona");    

}

